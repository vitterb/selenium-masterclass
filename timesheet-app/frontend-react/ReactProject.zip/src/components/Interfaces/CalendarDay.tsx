
export interface CalendarDay {
    date: Date;
    isWorkingMonth: boolean;
    isToday: boolean;
    formattedDate: string;
}