import { Employee } from "./EmployeeInterface";

export interface UserDropdownProps {
    employees: Employee[]; // Pass the list of employees as a prop
}