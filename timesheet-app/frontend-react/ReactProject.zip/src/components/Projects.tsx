export default function Projects() {
    return (
      <div>
        <h1>PlaceHolder for Projects</h1>
      </div>
    )
  }