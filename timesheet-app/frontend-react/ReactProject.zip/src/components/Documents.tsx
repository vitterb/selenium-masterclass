export default function Documents() {
    return (
      <div>
        <h1>PlaceHolder for Documents</h1>
      </div>
    )
  }